sqlite3 Restaurants.db < create.sql
sqlite3 Restaurants.db < load.txt